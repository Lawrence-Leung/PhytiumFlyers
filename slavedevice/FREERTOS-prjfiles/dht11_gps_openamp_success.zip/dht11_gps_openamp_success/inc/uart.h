#ifndef  UART_H
#define  UART_H

#include <stdio.h>

void UartWaitLoop(void);
void UartTaskCreate(void *args);

#endif
